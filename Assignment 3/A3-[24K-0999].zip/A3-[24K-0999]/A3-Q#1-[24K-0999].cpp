#include <iostream>
#include <string>
#include <fstream>
#include <stdexcept>
#include<exception>
using namespace std;

class TransportException : public exception {
private:
    string message;
public:
    explicit TransportException(const string& msg) : message(msg) {}
    ~TransportException() throw() {}
    const char* what() const throw() { 
        return message.c_str();
    }
};

class TransportCard {
private:
    static int nextCardID;
    int cardID;
    bool isActive;
public:
    TransportCard() : cardID(nextCardID++), isActive(false) {}
    TransportCard(int id, bool active) : cardID(id), isActive(active) {
        if (id >= nextCardID) nextCardID = id + 1;
    }
    
    void activate() { isActive = true; }
    void deactivate() { isActive = false; }
    bool getStatus() const { return isActive; }
    int getCardID() const { return cardID; }
    
    void saveToFile(ofstream& outFile) const {
        outFile << cardID << " " << isActive << " ";
    }
    
    static TransportCard readFromFile(ifstream& inFile) {
        int id;
        bool active;
        inFile >> id >> active;
        return TransportCard(id, active);
    }
};
int TransportCard::nextCardID = 1;

class User {
protected:
    string name;
    int ID;
    TransportCard card;
    
    virtual void saveSpecificData(ofstream& outFile) const = 0;
    virtual void loadSpecificData(ifstream& inFile) = 0;
    
public:
    User(string name, int ID) : name(name), ID(ID) {}
    User() : name(""), ID(0) {}
    
    virtual ~User() {}
    virtual void payFees() = 0;
    virtual string getUserType() const = 0;
    
    virtual void displayInfo() const {
        cout << "Name: " << name << ", ID: " << ID 
             << ", Card ID: " << card.getCardID()
             << ", Status: " << (card.getStatus() ? "Active" : "Inactive") << endl;
    }
    
    void saveToFile(ofstream& outFile) const {
        outFile << name << " " << ID << " ";
        card.saveToFile(outFile);
        saveSpecificData(outFile);
    }
    
    static User* loadFromFile(ifstream& inFile);
};

class Student : public User {
private:
    int semester;
    
    void saveSpecificData(ofstream& outFile) const override {
        outFile << semester << " ";
    }
    
    void loadSpecificData(ifstream& inFile) override {
        inFile >> semester;
    }
    
public:
    Student(string name, int ID, int sem = 1) : User(name, ID), semester(sem) {}
    Student() : User(), semester(1) {}
    
    void payFees() override {
        cout << "Student " << name << " paid semester fees." << endl;
        card.activate();
    }
    
    string getUserType() const override { return "Student"; }
    
    void displayInfo() const override {
        cout << "Student - ";
        User::displayInfo();
        cout << "  Semester: " << semester << endl;
    }
};

class Teacher : public User {
private:
    string department;
    
    void saveSpecificData(ofstream& outFile) const override {
        outFile << department << " ";
    }
    
    void loadSpecificData(ifstream& inFile) override {
        inFile >> department;
    }
    
public:
    Teacher(string name, int ID, string dept = "CS") 
        : User(name, ID), department(dept) {}
    Teacher() : User(), department("CS") {}
    
    void payFees() override {
        cout << "Teacher " << name << " paid monthly fees." << endl;
        card.activate();
    }
    
    string getUserType() const override { return "Teacher"; }
    
    void displayInfo() const override {
        cout << "Teacher - ";
        User::displayInfo();
        cout << "  Department: " << department << endl;
    }
};

class Staff : public User {
private:
    string position;
    
    void saveSpecificData(ofstream& outFile) const override {
        outFile << position << " ";
    }
    
    void loadSpecificData(ifstream& inFile) override {
        inFile >> position;
    }
    
public:
    Staff(string name, int ID, string pos = "General") 
        : User(name, ID), position(pos) {}
    Staff() : User(), position("General") {}
    
    void payFees() override {
        cout << "Staff " << name << " paid monthly fees." << endl;
        card.activate();
    }
    
    string getUserType() const override { return "Staff"; }
    
    void displayInfo() const override {
        cout << "Staff - ";
        User::displayInfo();
        cout << "  Position: " << position << endl;
    }
};

User* User::loadFromFile(ifstream& inFile) {
    string type;
    inFile >> type;
    
    User* user = NULL;
    if (type == "Student") {
        user = new Student();
    } else if (type == "Teacher") {
        user = new Teacher();
    } else if (type == "Staff") {
        user = new Staff();
    } else {
        throw TransportException("Unknown user type in file");
    }
    
    inFile >> user->name >> user->ID;
    user->card = TransportCard::readFromFile(inFile);
    user->loadSpecificData(inFile);
    return user;
}

class Stop {
private:
    string name;
    
public:
    Stop() : name("Undefined") {}
    Stop(string n) : name(n) {}
    
    string getName() const { return name; }
    
    void saveToFile(ofstream& outFile) const {
        outFile << name << " ";
    }
    
    static Stop readFromFile(ifstream& inFile) {
        string name;
        inFile >> name;
        return Stop(name);
    }
};

class Route {
private:
    static const int MAX_STOPS = 10;
    Stop stops[MAX_STOPS];
    int stopCount;
    
public:
    Route() : stopCount(0) {}
    
    void addStop(const Stop& stop) {
        if (stopCount < MAX_STOPS) {
            stops[stopCount] = stop;
            stopCount++;
        } else {
            throw TransportException("Maximum stops reached for route");
        }
    }
    
    bool operator==(const Route& other) const {
        if (stopCount != other.stopCount) return false;
        for (int i = 0; i < stopCount; i++) {
            if (stops[i].getName() != other.stops[i].getName()) return false;
        }
        return true;
    }
    
    int getStopCount() const { return stopCount; }
    
    void saveToFile(ofstream& outFile) const {
        outFile << stopCount << " ";
        for (int i = 0; i < stopCount; i++) {
            stops[i].saveToFile(outFile);
        }
    }
    
    static Route readFromFile(ifstream& inFile) {
        Route route;
        int count;
        inFile >> count;
        
        for (int i = 0; i < count; i++) {
            route.addStop(Stop::readFromFile(inFile));
        }
        return route;
    }
};

class TransportSystem {
private:
    static const int MAX_USERS = 100;
    static const int MAX_ROUTES = 20;
    
    User* users[MAX_USERS];
    Route routes[MAX_ROUTES];
    int userCount;
    int routeCount;
    
    void loadUsers() {
        ifstream inFile("users.dat");
        if (!inFile) return;
        
        try {
            inFile >> userCount;
            if (userCount > MAX_USERS) {
                throw TransportException("Too many users in file");
            }
            
            for (int i = 0; i < userCount; i++) {
                users[i] = User::loadFromFile(inFile);
            }
        } catch (const TransportException& e) {
            cerr << "Error loading users: " << e.what() << endl;
            userCount = 0;
        }
    }
    
    void loadRoutes() {
        ifstream inFile("routes.dat");
        if (!inFile) return;
        
        try {
            inFile >> routeCount;
            if (routeCount > MAX_ROUTES) {
                throw TransportException("Too many routes in file");
            }
            
            for (int i = 0; i < routeCount; i++) {
                routes[i] = Route::readFromFile(inFile);
            }
        } catch (const exception& e) {
            cerr << "Error loading routes: " << e.what() << endl;
            routeCount = 0;
        }
    }
    
public:
    TransportSystem() : userCount(0), routeCount(0) {
        loadUsers();
        loadRoutes();
    }
    
    ~TransportSystem() {
        for (int i = 0; i < userCount; i++) {
            delete users[i];
        }
    }
    
    void addUser(User* user) {
        if (!user) {
            throw TransportException("Attempt to add null user");
        }
        if (userCount >= MAX_USERS) {
            throw TransportException("Maximum user capacity reached");
        }
        users[userCount++] = user;
    }
    
    void addRoute(const Route& route) {
        if (routeCount >= MAX_ROUTES) {
            throw TransportException("Maximum route capacity reached");
        }
        routes[routeCount++] = route;
    }
    
    void saveAllData() {
        ofstream outFile("users.dat");
        if (!outFile) {
            throw TransportException("Failed to open users file for writing");
        }
        
        outFile << userCount << " ";
        for (int i = 0; i < userCount; i++) {
            outFile << users[i]->getUserType() << " ";
            users[i]->saveToFile(outFile);
        }
        
        ofstream routeFile("routes.dat");
        if (!routeFile) {
            throw TransportException("Failed to open routes file for writing");
        }
        
        routeFile << routeCount << " ";
        for (int i = 0; i < routeCount; i++) {
            routes[i].saveToFile(routeFile);
        }
    }
    
    void displayAllUsers() const {
        cout << "\n=== Registered Users (" << userCount << ") ===\n";
        for (int i = 0; i < userCount; i++) {
            users[i]->displayInfo();
        }
    }
    
    void displayAllRoutes() const {
        cout << "\n=== Available Routes (" << routeCount << ") ===\n";
        for (int i = 0; i < routeCount; i++) {
            cout << "Route " << i+1 << " with " << routes[i].getStopCount() << " stops\n";
        }
    }
};

int main() {
    try {
        TransportSystem system;
        
        if (true) {
		    Student* s = new Student("Asim", 191);
            Teacher* t = new Teacher("Dr. Akhtar", 754);
            Staff* staff = new Staff("Ms. Saima", 956);
            
            s->payFees();
            t->payFees();
            staff->payFees();
            
            system.addUser(s);
            system.addUser(t);
            system.addUser(staff);
            
            Route r1, r2;
            r1.addStop(Stop("A"));
            r1.addStop(Stop("B"));
            r2.addStop(Stop("C"));
            
            system.addRoute(r1);
            system.addRoute(r2);
        }
        
        system.displayAllUsers();
        system.displayAllRoutes();
        
        system.saveAllData();
        
    } catch (const TransportException& e) {
        cerr << "Transport System Error: " << e.what() << endl;
        return 1;
    } catch (const exception& e) {
        cerr << "General Error: " << e.what() << endl;
        return 1;
    }
    
    return 0;
}
