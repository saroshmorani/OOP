#include <iostream>
#include <cstring>

using namespace std;

class Skill {
public:
    int skillID;
    char skillName[50];
    char description[200];

    void showSkillDetails() {
        cout << "Skill ID: " << skillID << "\nName: " << skillName << "\nDescription: " << description << "\n";
    }

    void updateSkillDescription(const char* newDescription) {
        strncpy(description, newDescription, sizeof(description) - 1);
        description[sizeof(description) - 1] = '\0';
    }
};

class Sport {
public:
    int sportID;
    char name[50];
    char description[200];
    Skill requiredSkills[10];
    int skillCount;

    Sport() : skillCount(0) {}

    void addSkill(Skill s) {
        if (skillCount < 10) {
            requiredSkills[skillCount++] = s;
        } else {
            cout << "Cannot add more skills.\n";
        }
    }

    void removeSkill(int skillID) {
        for (int i = 0; i < skillCount; i++) {
            if (requiredSkills[i].skillID == skillID) {
                for (int j = i; j < skillCount - 1; j++) {
                    requiredSkills[j] = requiredSkills[j + 1];
                }
                skillCount--;
                return;
            }
        }
        cout << "Skill not found.\n";
    }
};

class Student;

class Mentor {
public:
    int mentorID;
    char name[50];
    Sport sportsExpertise[5];
    int expertiseCount;
    int maxLearners;
    Student* assignedLearners[5];
    int learnerCount;

    Mentor(int maxL) : maxLearners(maxL), learnerCount(0), expertiseCount(0) {}

    void assignLearner(Student* s);
    void removeLearner(Student* s);
    void viewLearners();
    void provideGuidance();
};

class Student {
public:
    int studentID;
    char name[50];
    int age;
    Sport sportsInterests[5];
    int sportsCount;
    Mentor* mentorAssigned;

    Student() : sportsCount(0), mentorAssigned(NULL) {}

    void registerForMentorship(Mentor* m);
    void viewMentorDetails();
    void updateSportsInterest(Sport s);
};

void Mentor::assignLearner(Student* s) {
    if (learnerCount < maxLearners) {
        assignedLearners[learnerCount++] = s;
        s->mentorAssigned = this;
    } else {
        cout << "Mentor is at full capacity.\n";
    }
}

void Mentor::removeLearner(Student* s) {
    for (int i = 0; i < learnerCount; i++) {
        if (assignedLearners[i] == s) {
            for (int j = i; j < learnerCount - 1; j++) {
                assignedLearners[j] = assignedLearners[j + 1];
            }
            learnerCount--;
            s->mentorAssigned = NULL;
            return;
        }
    }
    cout << "Student not found.\n";
}

void Mentor::viewLearners() {
    cout << "Mentor: " << name << "'s Learners:\n";
    for (int i = 0; i < learnerCount; i++) {
        cout << assignedLearners[i]->name<<endl;
    }
}

void Mentor::provideGuidance() {
    cout << "Guiding students in sports training.\n";
}

void Student::registerForMentorship(Mentor* m) {
    if (mentorAssigned == NULL) {
        m->assignLearner(this);
    } else {
        cout << "Student already has a mentor.\n";
    }
}

void Student::viewMentorDetails() {
    if (mentorAssigned != NULL) {
        cout << "Student: " << name << " - Mentor Name: " << mentorAssigned->name << "\n";
    } else {
        cout << "Student: " << name << " - No mentor assigned.\n";
    }
}

void Student::updateSportsInterest(Sport s) {
    if (sportsCount < 5) {
        sportsInterests[sportsCount++] = s;
    } else {
        cout << "Cannot add more sports interests.\n";
    }
}

int main() {
    Mentor mentor1(3);
    strcpy(mentor1.name, "Ali");
    
    Mentor mentor2(2);
    strcpy(mentor2.name, "Zain");

    Student student1;
    strcpy(student1.name, "Saad");

    Student student2;
    strcpy(student2.name, "Ahmed");

    Student student3;
    strcpy(student3.name, "Hasan");

    Student student4;
    strcpy(student4.name, "Bilal");

    student1.registerForMentorship(&mentor1);
    student2.registerForMentorship(&mentor1);
    student3.registerForMentorship(&mentor1);
    student4.registerForMentorship(&mentor2);

    mentor1.viewLearners();
    mentor2.viewLearners();
    student1.viewMentorDetails();
    student2.viewMentorDetails();
    student3.viewMentorDetails();
    student4.viewMentorDetails();
    mentor1.provideGuidance();
    mentor2.provideGuidance();

    return 0;
}