#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

class Ball {
private:
    int x, y;
public:
    Ball() : x(0), y(0) {} // Initializing
    
    int getX() { return x; }
    int getY() { return y; }
    
    void move(int dx, int dy) {
        x += dx;
        y += dy;
    }
};

class Robot {
private:
    string name;
    int hits;

public:
    Robot(string robotName) : name(robotName), hits(0) {}
    
    void hitBall(Ball &ball, const string &direction) {
        if (direction == "up") ball.move(0, 1);
        else if (direction == "down") ball.move(0, -1);
        else if (direction == "left") ball.move(-1, 0);
        else if (direction == "right") ball.move(1, 0);
        
        hits++;
    }
    
    int getHits() { return hits; }
    string getName() { return name; }
};

class Team {
private:
    string teamName;
    Robot *robot;
    
public:
    Team(string name, string robotName) {
        teamName = name;
        robot = new Robot(robotName);
    }
    
    ~Team() {
        delete robot;
    }
    
    string getTeamName() { return teamName; }
    Robot* getRobot() { return robot; }
};

class Game {
private:
    Team *teamOne;
    Team *teamTwo;
    Ball ball;
    const int goalX = 3, goalY = 3;
    
public:
    Game(string teamOneName, string robotOneName, string teamTwoName, string robotTwoName) {
        teamOne = new Team(teamOneName, robotOneName);
        teamTwo = new Team(teamTwoName, robotTwoName);
    }
    
    ~Game() {
        delete teamOne;
        delete teamTwo;
    }
    
    bool isGoalReached(int ballX, int ballY) {
        return (ballX == goalX && ballY == goalY);
    }
    
    void play(Team *team) {
        cout << team->getTeamName() << "'s robot " << team->getRobot()->getName() << " is playing...\n";
        
        int maxHits = 100; // Prevent infinite loops
        while (!isGoalReached(ball.getX(), ball.getY()) && maxHits > 0) {
            int ballX = ball.getX();
            int ballY = ball.getY();
            string direction;

            // Move towards (3,3) instead of random moves
            if (ballX < goalX) direction = "right";
            else if (ballX > goalX) direction = "left";
            else if (ballY < goalY) direction = "up";
            else if (ballY > goalY) direction = "down";

            team->getRobot()->hitBall(ball, direction);
            cout << "Ball moved " << direction << " to position: (" << ball.getX() << ", " << ball.getY() << ")\n";

            maxHits--; // Decrease max attempts
        }

        if (isGoalReached(ball.getX(), ball.getY()))
            cout << team->getTeamName() << " reached the goal in " << team->getRobot()->getHits() << " hits!\n\n";
        else
            cout << team->getTeamName() << " failed to reach the goal.\n\n";
    }
    
    void declareWinner() {
        if (teamOne->getRobot()->getHits() < teamTwo->getRobot()->getHits())
            cout << "Winner: " << teamOne->getTeamName() << "!\n";
        else if (teamTwo->getRobot()->getHits() < teamOne->getRobot()->getHits())
            cout << "Winner: " << teamTwo->getTeamName() << "!\n";
        else
            cout << "It's a tie!\n";
    }
    
    void startGame() {
        srand(time(0)); //random number generator
        play(teamOne);
        ball = Ball(); // Reset ball position
        play(teamTwo);
        declareWinner();
    }
};

int main() {
    Game game("Team A", "Robot Alpha", "Team B", "Robot Beta");
    game.startGame();
    return 0;
}