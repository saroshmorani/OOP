#include <iostream>
using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_STOPS = 10;
const int MAX_ROUTES = 5;
const int MAX_BUSES = 10;

class Student {
private:
    string studentID;
    string name;
    bool transportationCardActive;
    float balance;
    string assignedStop;

public:
    Student() : transportationCardActive(false), balance(0.0) {}

    void registerStudent(string id, string n, string stop) {
        studentID = id;
        name = n;
        assignedStop = stop;
        transportationCardActive = true;
        cout << name << " registered for transport at stop: " << stop << endl;
    }

    void payFees(float amount) {
        balance += amount;
        transportationCardActive = true;
        cout << name << " paid " << amount << ". Card is active." << endl;
    }

    void tapCard() {
        if (transportationCardActive) {
            cout << name << " tapped card. Attendance recorded." << endl;
        } else {
            cout << "Access denied! Please pay fees." << endl;
        }
    }

    string getID() { return studentID; }
    string getName() { return name; }
};

class BusStop {
private:
    string stopID;
    string location;
    Student* assignedStudents[MAX_STUDENTS];
    int studentCount;

public:
    BusStop() : studentCount(0) {}

    void setStop(string id, string loc) {
        stopID = id;
        location = loc;
    }

    void assignStudent(Student* s) {
        if (studentCount < MAX_STUDENTS) {
            assignedStudents[studentCount++] = s;
            cout << "Student " << s->getName() << " assigned to stop " << location << endl;
        } else {
            cout << "Stop " << location << " is full!" << endl;
        }
    }

    string getLocation() { return location; }
};

class BusRoute {
private:
    string routeID;
    BusStop* busStops[MAX_STOPS];
    int stopCount;

public:
    BusRoute() : stopCount(0) {}

    void setRoute(string id) {
        routeID = id;
    }

    void addStop(BusStop* stop) {
        if (stopCount < MAX_STOPS) {
            busStops[stopCount++] = stop;
            cout << "Stop " << stop->getLocation() << " added to route " << routeID << endl;
        } else {
            cout << "Route " << routeID << " is full!" << endl;
        }
    }
};

class Bus {
private:
    string busID;
    BusRoute* assignedRoute;

public:
    Bus() : assignedRoute(nullptr) {}

    void setBus(string id) {
        busID = id;
    }

    void setRoute(BusRoute* route) {
        assignedRoute = route;
        cout << "Bus " << busID << " assigned to route." << endl;
    }
};

class TransportationSystem {
private:
    Student students[MAX_STUDENTS];
    Bus buses[MAX_BUSES];
    BusRoute routes[MAX_ROUTES];
    BusStop stops[MAX_STOPS];

    int studentCount, busCount, routeCount, stopCount;

public:
    TransportationSystem() : studentCount(0), busCount(0), routeCount(0), stopCount(0) {}

    void registerStudent(string id, string name, string stop) {
        if (studentCount < MAX_STUDENTS) {
            students[studentCount].registerStudent(id, name, stop);
            studentCount++;
        } else {
            cout << "Max student limit reached!" << endl;
        }
    }

    void addStop(string id, string location) {
        if (stopCount < MAX_STOPS) {
            stops[stopCount].setStop(id, location);
            stopCount++;
        } else {
            cout << "Max stops reached!" << endl;
        }
    }

    void addRoute(string id) {
        if (routeCount < MAX_ROUTES) {
            routes[routeCount].setRoute(id);
            routeCount++;
        } else {
            cout << "Max routes reached!" << endl;
        }
    }

    void addBus(string id) {
        if (busCount < MAX_BUSES) {
            buses[busCount].setBus(id);
            busCount++;
        } else {
            cout << "Max buses reached!" << endl;
        }
    }
};

int main() {
    TransportationSystem system;

    system.addStop("B1", "Main Gate");
    system.addStop("B2", "One Stop");
    system.addRoute("R1");
    system.addBus("Bus10");

    system.registerStudent("S101", "Asim", "Main Gate");
    system.registerStudent("S102", "Sana", "One Stop");

    return 0;
}
