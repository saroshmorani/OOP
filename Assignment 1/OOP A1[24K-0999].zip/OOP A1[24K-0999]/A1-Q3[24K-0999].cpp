#include <iostream>
#include <string>

using namespace std;

class User {
private:
    string name;
    int age;
    string licenseType;
    string contactInfo;
    int userID;

public:
    User(string n, int a, string l, string c, int id) : name(n), age(a), licenseType(l), contactInfo(c), userID(id) {}

    void updateDetails(string newName, int newAge, string newLicense, string newContact) {
        name = newName;
        age = newAge;
        licenseType = newLicense;
        contactInfo = newContact;
    }

    int getUserID() const { return userID; }
    string getName() const { return name; }
    string getLicenseType() const { return licenseType; }
};

class Vehicle {
private:
    string model;
    double rentalPricePerDay;
    string requiredLicense;

public:
    Vehicle(string m, double r, string rl) : model(m), rentalPricePerDay(r), requiredLicense(rl) {}

    bool isEligible(string userLicense) {
        if (userLicense == requiredLicense) return true;
        if (requiredLicense == "Full" && (userLicense == "Intermediate" || userLicense == "Learner")) return false;
        if (requiredLicense == "Intermediate" && userLicense == "Learner") return false;
        return false;
    }

    string getModel() const { return model; }
    double getRentalPricePerDay() const { return rentalPricePerDay; }
    string getRequiredLicense() const { return requiredLicense; }
};

class RentalSystem {
private:
    User** users;
    Vehicle** vehicles;
    int userCount;
    int vehicleCount;
    int userCapacity;
    int vehicleCapacity;

public:
    RentalSystem() : userCount(0), vehicleCount(0), userCapacity(2), vehicleCapacity(2) {
        users = new User*[userCapacity];
        vehicles = new Vehicle*[vehicleCapacity];
    }
    
    ~RentalSystem() {
        for (int i = 0; i < userCount; i++) delete users[i];
        for (int i = 0; i < vehicleCount; i++) delete vehicles[i];
        delete[] users;
        delete[] vehicles;
    }

    void expandUsers() {
        userCapacity *= 2;
        User** newUsers = new User*[userCapacity];
        for (int i = 0; i < userCount; i++) newUsers[i] = users[i];
        delete[] users;
        users = newUsers;
    }

    void expandVehicles() {
        vehicleCapacity *= 2;
        Vehicle** newVehicles = new Vehicle*[vehicleCapacity];
        for (int i = 0; i < vehicleCount; i++) newVehicles[i] = vehicles[i];
        delete[] vehicles;
        vehicles = newVehicles;
    }

    void registerUser(string name, int age, string license, string contact, int id) {
        if (userCount >= userCapacity) expandUsers();
        users[userCount++] = new User(name, age, license, contact, id);
        cout << "User registered successfully!\n";
    }

    void updateUser(int id, string newName, int newAge, string newLicense, string newContact) {
        for (int i = 0; i < userCount; i++) {
            if (users[i]->getUserID() == id) {
                users[i]->updateDetails(newName, newAge, newLicense, newContact);
                cout << "User details updated successfully!\n";
                return;
            }
        }
        cout << "User not found!\n";
    }

    void addVehicle(string model, double price, string licenseReq) {
        if (vehicleCount >= vehicleCapacity) expandVehicles();
        vehicles[vehicleCount++] = new Vehicle(model, price, licenseReq);
    }

    void displayVehicles() {
        cout << "Available Vehicles:\n";
        for (int i = 0; i < vehicleCount; i++) {
            cout << i + 1 << ". " << vehicles[i]->getModel() << " - $" << vehicles[i]->getRentalPricePerDay() << "/day (License Required: " << vehicles[i]->getRequiredLicense() << ")\n";
        }
    }

    void rentVehicle(int userID, int vehicleIndex) {
        if (vehicleIndex < 1 || vehicleIndex > vehicleCount) {
            cout << "Invalid vehicle selection!\n";
            return;
        }
        
        Vehicle* selectedVehicle = vehicles[vehicleIndex - 1];
        for (int i = 0; i < userCount; i++) {
            if (users[i]->getUserID() == userID) {
                if (selectedVehicle->isEligible(users[i]->getLicenseType())) {
                    cout << "Vehicle rented successfully!\n";
                    cout << "User: " << users[i]->getName() << " has rented " << selectedVehicle->getModel() << " for $" << selectedVehicle->getRentalPricePerDay() << " per day.\n";
                } else {
                    cout << "You are not eligible to rent this vehicle!\n";
                }
                return;
            }
        }
        cout << "User not found!\n";
    }
};

int main() {
    RentalSystem system;
    
    system.addVehicle("Toyota Rivo", 50, "Full");
    system.addVehicle("Honda Civic", 45, "Intermediate");
    system.addVehicle("Audi A6", 30, "Learner");
    
    system.registerUser("Alyssa", 27, "Full", "12462477", 1);
    system.registerUser("Babar", 20, "Learner", "09878976", 2);
    
    system.displayVehicles();
    
    system.rentVehicle(1, 1); 
    system.rentVehicle(2, 1); 
    system.rentVehicle(2, 3);
    
    return 0;
}